<meta charset="utf-8">
	    <meta http-equiv="X-UA-Compatible" content="IE=edge">
	    <meta name="viewport" content="width=device-width, initial-scale=1">
	    <meta name="description" content="">
	    <meta name="author" content="">

	    <title>MAG Initiatives</title>

	    <link href="{{ URL::asset('css/bootstrap.min.css') }}" rel="stylesheet">

	    <link href="{{ URL::asset('font-awesome/css/font-awesome.min.css') }}" rel="stylesheet" type="text/css">
    	<link href="{{ URL::asset('http://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,700,300italic,400italic,700italic') }}" rel="stylesheet" type="text/css">
    	<link href="{{ URL::asset('https://fonts.googleapis.com/css?family=Open+Sans:400,600,600italic,700,700italic,800,800italic,400italic,300italic,300') }}" rel='stylesheet' type='text/css'>

	    <script src="{{ URL::asset('https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js') }}"></script>
		<script src="{{ URL::asset('js/bootstrap.min.js') }}"></script>
		<script src="{{ URL::asset('js/notify.min.js') }}"></script>	
			
