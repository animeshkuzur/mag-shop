<?php namespace App;

use Illuminate\Database\Eloquent\Model;

class Transaction_Detail extends Model {

	//

}
