<?php namespace App;

use Illuminate\Database\Eloquent\Model;

class NotifyUser extends Model {

	//

}
